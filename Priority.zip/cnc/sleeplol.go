package main

import (
	"time"
)

func s() {
	time.Sleep(100 * time.Millisecond)
}
